#!/bin/bash
# FANTAZMA NETWORK - QUICK START SCRIPT
# Run this after setting up your .env file

echo "=========================================="
echo "  FANTAZMA NETWORK BACKEND SETUP"
echo "=========================================="
echo ""

# Check if .env exists
if [ ! -f .env ]; then
    echo "❌ .env file not found!"
    echo "   Copy .env.example to .env and fill in your values"
    exit 1
fi

# Check if Node.js is installed
if ! command -v node &> /dev/null; then
    echo "❌ Node.js not found!"
    echo "   Install from: https://nodejs.org/"
    exit 1
fi

echo "✅ Node.js version: $(node --version)"
echo ""

# Install dependencies
echo "📦 Installing dependencies..."
npm install

# Check if MongoDB URI is set
if grep -q "<YOUR_PASSWORD>" .env; then
    echo ""
    echo "⚠️  WARNING: You haven't set your MongoDB password yet!"
    echo "   Edit .env and replace <YOUR_PASSWORD> with your actual password"
    echo ""
fi

# Start server
echo "🚀 Starting server..."
echo "   API: http://localhost:10000/api/health"
echo "   WebSocket: ws://localhost:10000"
echo ""
npm start