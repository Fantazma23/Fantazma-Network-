const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const WebSocket = require('ws');
const http = require('http');
const axios = require('axios');
const cron = require('node-cron');
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

// ========== SECURITY MIDDLEWARE ==========
app.use(helmet({
    contentSecurityPolicy: {
        directives: {
            defaultSrc: ["'self'"],
            connectSrc: ["'self'", "https://api.coingecko.com", "https://api.stripe.com"],
            imgSrc: ["'self'", "https:", "data:"],
            scriptSrc: ["'self'", "'unsafe-inline'"],
            styleSrc: ["'self'", "'unsafe-inline'", "https://fonts.googleapis.com"],
            fontSrc: ["'self'", "https://fonts.gstatic.com"]
        }
    }
}));

app.use(cors({
    origin: process.env.FRONTEND_URL || ['https://fantazma-network.onrender.com', 'http://localhost:3000'],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization']
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: { success: false, error: 'Too many requests, please try again later.' }
});
app.use(limiter);

// Stricter rate limit for auth endpoints
const authLimiter = rateLimit({
    windowMs: 60 * 60 * 1000,
    max: 10,
    message: { success: false, error: 'Too many login attempts. Please try again in an hour.' }
});

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

const PORT = process.env.PORT || 10000;

// ========== MONGODB CONNECTION ==========
let isConnected = false;

async function connectDB() {
    try {
        if (!process.env.MONGODB_URI) {
            console.log('[DB] No MONGODB_URI found. Running in memory-only mode.');
            return false;
        }

        await mongoose.connect(process.env.MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: 5000
        });

        isConnected = true;
        console.log('[DB] MongoDB connected successfully');
        return true;
    } catch (error) {
        console.error('[DB] MongoDB connection failed:', error.message);
        console.log('[DB] Falling back to in-memory mode');
        return false;
    }
}

connectDB();

// ========== MONGOOSE SCHEMAS ==========
const UserSchema = new mongoose.Schema({
    email: { type: String, unique: true, sparse: true },
    password: { type: String },
    wallet: { type: String, enum: ['metamask', 'walletconnect', 'coinbase', null] },
    walletAddress: { type: String, unique: true, sparse: true },
    name: { type: String, default: 'User' },
    subscription: {
        type: { type: String, enum: ['none', 'monthly', 'yearly', 'lifetime'], default: 'none' },
        status: { type: String, enum: ['active', 'expired', 'cancelled'], default: 'none' },
        startedAt: Date,
        expiresAt: Date,
        paymentMethod: { type: String, enum: ['crypto', 'card'], default: null }
    },
    role: { type: String, enum: ['user', 'admin', 'moderator'], default: 'user' },
    referralCode: { type: String, unique: true },
    referredBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    createdAt: { type: Date, default: Date.now },
    lastLogin: { type: Date, default: Date.now },
    isActive: { type: Boolean, default: true }
});

UserSchema.pre('save', async function(next) {
    if (this.isModified('password') && this.password) {
        this.password = await bcrypt.hash(this.password, 12);
    }
    if (!this.referralCode) {
        this.referralCode = 'FAN' + Math.random().toString(36).substr(2, 8).toUpperCase();
    }
    next();
});

UserSchema.methods.comparePassword = async function(candidatePassword) {
    if (!this.password) return false;
    return await bcrypt.compare(candidatePassword, this.password);
};

const PaymentSchema = new mongoose.Schema({
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    plan: { type: String, enum: ['monthly', 'yearly', 'lifetime'], required: true },
    amount: { type: Number, required: true },
    fee: { type: Number, default: 0 },
    method: { type: String, enum: ['crypto', 'card'], required: true },
    status: { type: String, enum: ['pending', 'completed', 'failed', 'refunded'], default: 'pending' },
    stripeSessionId: { type: String },
    stripePaymentIntentId: { type: String },
    coinbaseChargeId: { type: String },
    txHash: { type: String }, // For crypto payments
    createdAt: { type: Date, default: Date.now },
    completedAt: { type: Date }
});

const ChatMessageSchema = new mongoose.Schema({
    username: { type: String, required: true },
    text: { type: String, required: true },
    color: { type: String, default: '#00d4ff' },
    wallet: { type: String },
    address: { type: String },
    timestamp: { type: Date, default: Date.now },
    isDeleted: { type: Boolean, default: false }
});

const User = mongoose.model('User', UserSchema);
const Payment = mongoose.model('Payment', PaymentSchema);
const ChatMessage = mongoose.model('ChatMessage', ChatMessageSchema);

// ========== IN-MEMORY FALLBACKS ==========
let memoryUsers = [];
let memoryPayments = [];
let memoryChatMessages = [];

// ========== STRIPE SETUP ==========
let stripe;
try {
    if (process.env.STRIPE_SECRET_KEY) {
        stripe = require('stripe')(process.env.STRIPE_SECRET_KEY);
        console.log('[Stripe] Initialized successfully');
    } else {
        console.log('[Stripe] No STRIPE_SECRET_KEY found. Card payments disabled.');
    }
} catch (error) {
    console.error('[Stripe] Failed to initialize:', error.message);
}

// ========== COINGECKO CRYPTO PRICES ==========
const COINGECKO_API = 'https://api.coingecko.com/api/v3';
const TRACKED_COINS = [
    'bitcoin', 'ethereum', 'tether', 'binancecoin', 'solana',
    'ripple', 'usd-coin', 'cardano', 'dogecoin', 'polkadot',
    'chainlink', 'polygon', 'avalanche-2', 'litecoin', 'uniswap'
];

let cryptoPrices = [];
let connectedUsers = new Map();
let onlineViewers = 0;

async function fetchCryptoPrices() {
    try {
        const response = await axios.get(`${COINGECKO_API}/coins/markets`, {
            params: {
                vs_currency: 'usd',
                ids: TRACKED_COINS.join(','),
                order: 'market_cap_desc',
                per_page: 20,
                page: 1,
                sparkline: true,
                price_change_percentage: '24h,7d'
            },
            timeout: 10000,
            headers: process.env.COINGECKO_API_KEY ? { 'x-cg-demo-api-key': process.env.COINGECKO_API_KEY } : {}
        });

        cryptoPrices = response.data.map(coin => ({
            id: coin.id,
            symbol: coin.symbol.toUpperCase(),
            name: coin.name,
            current_price: coin.current_price,
            market_cap: coin.market_cap,
            total_volume: coin.total_volume,
            price_change_24h: coin.price_change_percentage_24h,
            price_change_7d: coin.price_change_percentage_7d_in_currency,
            image: coin.image,
            sparkline_in_7d: coin.sparkline_in_7d,
            last_updated: new Date().toISOString()
        }));

        console.log(`[${new Date().toISOString()}] Crypto prices updated: ${cryptoPrices.length} coins`);

        broadcastToAll({ type: 'crypto_update', data: cryptoPrices });
    } catch (error) {
        console.error('Error fetching crypto prices:', error.message);
        if (cryptoPrices.length === 0) {
            cryptoPrices = getFallbackPrices();
        }
    }
}

function getFallbackPrices() {
    return [
        { id: 'bitcoin', symbol: 'BTC', name: 'Bitcoin', current_price: 97432.50, market_cap: 1920000000000, total_volume: 28500000000, price_change_24h: 2.4, price_change_7d: 5.1 },
        { id: 'ethereum', symbol: 'ETH', name: 'Ethereum', current_price: 3847.20, market_cap: 462000000000, total_volume: 15200000000, price_change_24h: 1.8, price_change_7d: 3.2 },
        { id: 'tether', symbol: 'USDT', name: 'Tether', current_price: 1.00, market_cap: 118000000000, total_volume: 52000000000, price_change_24h: 0.01, price_change_7d: 0.02 },
        { id: 'solana', symbol: 'SOL', name: 'Solana', current_price: 142.50, market_cap: 68000000000, total_volume: 3200000000, price_change_24h: 5.2, price_change_7d: 12.4 },
        { id: 'ripple', symbol: 'XRP', name: 'XRP', current_price: 2.14, market_cap: 123000000000, total_volume: 2800000000, price_change_24h: 1.5, price_change_7d: -2.1 },
        { id: 'binancecoin', symbol: 'BNB', name: 'BNB', current_price: 712.40, market_cap: 104000000000, total_volume: 1800000000, price_change_24h: 0.9, price_change_7d: 1.2 },
        { id: 'usd-coin', symbol: 'USDC', name: 'USD Coin', current_price: 1.00, market_cap: 42000000000, total_volume: 8500000000, price_change_24h: 0.00, price_change_7d: 0.01 },
        { id: 'cardano', symbol: 'ADA', name: 'Cardano', current_price: 0.89, market_cap: 31000000000, total_volume: 450000000, price_change_24h: -1.2, price_change_7d: -3.5 },
        { id: 'dogecoin', symbol: 'DOGE', name: 'Dogecoin', current_price: 0.18, market_cap: 26000000000, total_volume: 1200000000, price_change_24h: 3.7, price_change_7d: 8.9 },
        { id: 'polkadot', symbol: 'DOT', name: 'Polkadot', current_price: 6.72, market_cap: 9500000000, total_volume: 280000000, price_change_24h: 3.1, price_change_7d: 6.7 }
    ];
}

fetchCryptoPrices();
cron.schedule('*/2 * * * *', fetchCryptoPrices);

// ========== WEBSOCKET LIVE CHAT ==========
wss.on('connection', (ws, req) => {
    const clientId = Date.now() + Math.random().toString(36).substr(2, 9);
    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress;

    console.log(`[WS] Client connected: ${clientId} from ${clientIp}`);
    onlineViewers++;
    connectedUsers.set(clientId, { ws, username: null, joinedAt: new Date() });

    ws.send(JSON.stringify({
        type: 'system',
        message: 'Welcome to Fantazma Network chat!',
        onlineCount: onlineViewers
    }));

    // Send last 50 messages from DB or memory
    sendChatHistory(ws);

    broadcastToAll({
        type: 'user_joined',
        onlineCount: onlineViewers,
        message: 'A viewer joined the chat'
    });

    ws.on('message', async (data) => {
        try {
            const message = JSON.parse(data);

            switch (message.type) {
                case 'chat':
                    await handleChatMessage(clientId, message);
                    break;
                case 'auth':
                    handleAuth(clientId, message);
                    break;
                case 'ping':
                    ws.send(JSON.stringify({ type: 'pong' }));
                    break;
            }
        } catch (err) {
            console.error('[WS] Message parse error:', err);
        }
    });

    ws.on('close', () => {
        console.log(`[WS] Client disconnected: ${clientId}`);
        onlineViewers = Math.max(0, onlineViewers - 1);
        connectedUsers.delete(clientId);

        broadcastToAll({
            type: 'user_left',
            onlineCount: onlineViewers,
            message: 'A viewer left the chat'
        });
    });

    ws.on('error', (err) => {
        console.error(`[WS] Error for ${clientId}:`, err);
    });
});

async function sendChatHistory(ws) {
    try {
        let messages;
        if (isConnected) {
            messages = await ChatMessage.find({ isDeleted: false })
                .sort({ timestamp: -1 })
                .limit(50)
                .lean();
            messages.reverse();
        } else {
            messages = memoryChatMessages.slice(-50);
        }

        ws.send(JSON.stringify({ type: 'history', messages }));
    } catch (error) {
        console.error('Error sending chat history:', error);
    }
}

async function handleChatMessage(clientId, message) {
    const user = connectedUsers.get(clientId);
    if (!user) return;

    const username = user.username || `Guest_${clientId.slice(-4)}`;
    const chatMessage = {
        id: Date.now() + Math.random().toString(36).substr(2, 9),
        type: 'chat',
        username: username,
        text: sanitizeText(message.text),
        timestamp: new Date().toISOString(),
        color: message.color || '#00d4ff'
    };

    // Save to DB or memory
    try {
        if (isConnected) {
            await ChatMessage.create({
                username: chatMessage.username,
                text: chatMessage.text,
                color: chatMessage.color,
                wallet: user.wallet,
                address: user.address
            });
        } else {
            memoryChatMessages.push(chatMessage);
            if (memoryChatMessages.length > 500) {
                memoryChatMessages = memoryChatMessages.slice(-500);
            }
        }
    } catch (error) {
        console.error('Error saving chat message:', error);
    }

    broadcastToAll(chatMessage);
}

function handleAuth(clientId, message) {
    const user = connectedUsers.get(clientId);
    if (user) {
        user.username = message.username || message.address || `User_${clientId.slice(-4)}`;
        user.wallet = message.wallet || null;
        user.address = message.address || null;

        user.ws.send(JSON.stringify({
            type: 'auth_success',
            username: user.username
        }));
    }
}

function broadcastToAll(data) {
    const message = JSON.stringify(data);
    connectedUsers.forEach((user) => {
        if (user.ws.readyState === WebSocket.OPEN) {
            user.ws.send(message);
        }
    });
}

function sanitizeText(text) {
    if (!text || typeof text !== 'string') return '';
    return text.replace(/</g, '&lt;').replace(/>/g, '&gt;').substring(0, 500);
}

// ========== JWT MIDDLEWARE ==========
function authenticateToken(req, res, next) {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ success: false, error: 'Access token required' });
    }

    jwt.verify(token, process.env.JWT_SECRET || 'fantazma-secret-key', (err, user) => {
        if (err) {
            return res.status(403).json({ success: false, error: 'Invalid or expired token' });
        }
        req.user = user;
        next();
    });
}

// ========== AUTH ROUTES ==========
app.post('/api/auth/register', authLimiter, async (req, res) => {
    try {
        const { email, password, name } = req.body;

        if (!email || !password) {
            return res.status(400).json({ success: false, error: 'Email and password required' });
        }

        if (password.length < 6) {
            return res.status(400).json({ success: false, error: 'Password must be at least 6 characters' });
        }

        let user;
        if (isConnected) {
            const existingUser = await User.findOne({ email: email.toLowerCase() });
            if (existingUser) {
                return res.status(409).json({ success: false, error: 'Email already registered' });
            }

            user = new User({
                email: email.toLowerCase(),
                password,
                name: name || email.split('@')[0]
            });
            await user.save();
        } else {
            const existing = memoryUsers.find(u => u.email === email.toLowerCase());
            if (existing) {
                return res.status(409).json({ success: false, error: 'Email already registered' });
            }

            const hashedPassword = await bcrypt.hash(password, 12);
            user = {
                _id: Date.now().toString(),
                email: email.toLowerCase(),
                password: hashedPassword,
                name: name || email.split('@')[0],
                createdAt: new Date(),
                referralCode: 'FAN' + Math.random().toString(36).substr(2, 8).toUpperCase()
            };
            memoryUsers.push(user);
        }

        const token = jwt.sign(
            { userId: user._id, email: user.email, role: user.role || 'user' },
            process.env.JWT_SECRET || 'fantazma-secret-key',
            { expiresIn: '7d' }
        );

        res.status(201).json({
            success: true,
            token,
            user: {
                id: user._id,
                email: user.email,
                name: user.name,
                referralCode: user.referralCode,
                subscription: user.subscription || { type: 'none', status: 'none' }
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ success: false, error: 'Registration failed' });
    }
});

app.post('/api/auth/login', authLimiter, async (req, res) => {
    try {
        const { email, password, wallet, address } = req.body;
        let user;

        if (email && password) {
            // Email/password login
            if (isConnected) {
                user = await User.findOne({ email: email.toLowerCase() });
            } else {
                user = memoryUsers.find(u => u.email === email.toLowerCase());
            }

            if (!user || !user.password) {
                return res.status(401).json({ success: false, error: 'Invalid email or password' });
            }

            const isValid = await bcrypt.compare(password, user.password);
            if (!isValid) {
                return res.status(401).json({ success: false, error: 'Invalid email or password' });
            }
        } else if (wallet && address) {
            // Wallet login
            if (isConnected) {
                user = await User.findOne({ walletAddress: address.toLowerCase() });
                if (!user) {
                    user = new User({
                        wallet,
                        walletAddress: address.toLowerCase(),
                        name: address.slice(0, 6) + '...' + address.slice(-4)
                    });
                    await user.save();
                }
            } else {
                user = memoryUsers.find(u => u.walletAddress === address.toLowerCase());
                if (!user) {
                    user = {
                        _id: Date.now().toString(),
                        wallet,
                        walletAddress: address.toLowerCase(),
                        name: address.slice(0, 6) + '...' + address.slice(-4),
                        createdAt: new Date()
                    };
                    memoryUsers.push(user);
                }
            }
        } else {
            return res.status(400).json({ success: false, error: 'Invalid login credentials' });
        }

        // Update last login
        if (isConnected) {
            user.lastLogin = new Date();
            await user.save();
        }

        const token = jwt.sign(
            { userId: user._id, email: user.email, role: user.role || 'user' },
            process.env.JWT_SECRET || 'fantazma-secret-key',
            { expiresIn: '7d' }
        );

        res.json({
            success: true,
            token,
            user: {
                id: user._id,
                email: user.email,
                name: user.name,
                wallet: user.wallet,
                walletAddress: user.walletAddress,
                referralCode: user.referralCode,
                subscription: user.subscription || { type: 'none', status: 'none' }
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ success: false, error: 'Login failed' });
    }
});

app.get('/api/auth/me', authenticateToken, async (req, res) => {
    try {
        let user;
        if (isConnected) {
            user = await User.findById(req.user.userId).select('-password');
        } else {
            user = memoryUsers.find(u => u._id === req.user.userId);
        }

        if (!user) {
            return res.status(404).json({ success: false, error: 'User not found' });
        }

        res.json({
            success: true,
            user: {
                id: user._id,
                email: user.email,
                name: user.name,
                wallet: user.wallet,
                walletAddress: user.walletAddress,
                referralCode: user.referralCode,
                subscription: user.subscription || { type: 'none', status: 'none' },
                role: user.role || 'user'
            }
        });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Failed to get user' });
    }
});

// ========== STRIPE PAYMENT ROUTES ==========
app.post('/api/payment/create-session', authenticateToken, async (req, res) => {
    try {
        const { plan, method } = req.body;

        if (!stripe) {
            return res.status(503).json({ success: false, error: 'Stripe not configured. Add STRIPE_SECRET_KEY to environment variables.' });
        }

        const prices = {
            monthly: { amount: method === 'card' ? 688 : 499, currency: 'usd', name: 'Monthly Subscription' },
            yearly: { amount: method === 'card' ? 5188 : 4999, currency: 'usd', name: 'Yearly Subscription' },
            lifetime: { amount: method === 'card' ? 20089 : 19900, currency: 'usd', name: 'Lifetime Access' }
        };

        const price = prices[plan];
        if (!price) {
            return res.status(400).json({ success: false, error: 'Invalid plan' });
        }

        const fee = method === 'card' ? 189 : 0; // $1.89 in cents
        const totalAmount = price.amount + fee;

        // Create Stripe Checkout Session
        const session = await stripe.checkout.sessions.create({
            payment_method_types: ['card'],
            line_items: [{
                price_data: {
                    currency: price.currency,
                    product_data: {
                        name: price.name,
                        description: method === 'card' ? 'Includes $1.89 processing fee' : 'Zero fees with crypto',
                        images: ['https://fantazma-network.onrender.com/logo.png']
                    },
                    unit_amount: totalAmount
                },
                quantity: 1
            }],
            mode: 'payment',
            success_url: `${process.env.FRONTEND_URL || 'https://fantazma-network.onrender.com'}/dashboard.html?payment=success&plan=${plan}`,
            cancel_url: `${process.env.FRONTEND_URL || 'https://fantazma-network.onrender.com'}/dashboard.html?payment=cancelled`,
            metadata: {
                userId: req.user.userId,
                plan: plan,
                method: method,
                fee: fee
            }
        });

        // Save payment record
        const paymentRecord = {
            userId: req.user.userId,
            plan,
            amount: totalAmount / 100,
            fee: fee / 100,
            method,
            status: 'pending',
            stripeSessionId: session.id,
            createdAt: new Date()
        };

        if (isConnected) {
            await Payment.create(paymentRecord);
        } else {
            memoryPayments.push(paymentRecord);
        }

        res.json({
            success: true,
            sessionId: session.id,
            url: session.url,
            plan,
            amount: totalAmount / 100,
            fee: fee / 100,
            message: method === 'card' ? 'Card payment includes $1.89 processing fee' : 'Zero fees with crypto!'
        });
    } catch (error) {
        console.error('Stripe session creation error:', error);
        res.status(500).json({ success: false, error: 'Failed to create payment session' });
    }
});

app.post('/api/payment/webhook', express.raw({ type: 'application/json' }), async (req, res) => {
    const sig = req.headers['stripe-signature'];
    let event;

    try {
        event = stripe.webhooks.constructEvent(req.body, sig, process.env.STRIPE_WEBHOOK_SECRET);
    } catch (err) {
        console.error('Webhook signature verification failed:', err.message);
        return res.status(400).send(`Webhook Error: ${err.message}`);
    }

    if (event.type === 'checkout.session.completed') {
        const session = event.data.object;

        try {
            let payment;
            if (isConnected) {
                payment = await Payment.findOneAndUpdate(
                    { stripeSessionId: session.id },
                    { status: 'completed', completedAt: new Date(), stripePaymentIntentId: session.payment_intent },
                    { new: true }
                );

                // Update user subscription
                if (payment) {
                    const expiresAt = new Date();
                    if (payment.plan === 'monthly') expiresAt.setMonth(expiresAt.getMonth() + 1);
                    else if (payment.plan === 'yearly') expiresAt.setFullYear(expiresAt.getFullYear() + 1);
                    else if (payment.plan === 'lifetime') expiresAt.setFullYear(expiresAt.getFullYear() + 100);

                    await User.findByIdAndUpdate(payment.userId, {
                        'subscription.type': payment.plan,
                        'subscription.status': 'active',
                        'subscription.startedAt': new Date(),
                        'subscription.expiresAt': expiresAt,
                        'subscription.paymentMethod': 'card'
                    });
                }
            } else {
                payment = memoryPayments.find(p => p.stripeSessionId === session.id);
                if (payment) {
                    payment.status = 'completed';
                    payment.completedAt = new Date();

                    const user = memoryUsers.find(u => u._id === payment.userId);
                    if (user) {
                        const expiresAt = new Date();
                        if (payment.plan === 'monthly') expiresAt.setMonth(expiresAt.getMonth() + 1);
                        else if (payment.plan === 'yearly') expiresAt.setFullYear(expiresAt.getFullYear() + 1);
                        else if (payment.plan === 'lifetime') expiresAt.setFullYear(expiresAt.getFullYear() + 100);

                        user.subscription = {
                            type: payment.plan,
                            status: 'active',
                            startedAt: new Date(),
                            expiresAt,
                            paymentMethod: 'card'
                        };
                    }
                }
            }

            console.log(`[Stripe] Payment completed: ${session.id}`);
        } catch (error) {
            console.error('Webhook processing error:', error);
        }
    }

    res.json({ received: true });
});

// Crypto payment endpoint (manual verification)
app.post('/api/payment/crypto', authenticateToken, async (req, res) => {
    try {
        const { plan, txHash } = req.body;

        const prices = {
            monthly: 4.99,
            yearly: 49.99,
            lifetime: 199.00
        };

        const paymentRecord = {
            userId: req.user.userId,
            plan,
            amount: prices[plan],
            fee: 0,
            method: 'crypto',
            status: 'pending',
            txHash,
            createdAt: new Date()
        };

        if (isConnected) {
            await Payment.create(paymentRecord);
        } else {
            memoryPayments.push(paymentRecord);
        }

        res.json({
            success: true,
            message: 'Crypto payment submitted for verification',
            plan,
            amount: prices[plan],
            fee: 0,
            txHash
        });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Failed to process crypto payment' });
    }
});

// ========== EXISTING API ROUTES ==========
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        timestamp: new Date().toISOString(),
        dbConnected: isConnected,
        onlineViewers: onlineViewers,
        connectedClients: connectedUsers.size,
        stripeEnabled: !!stripe,
        uptime: process.uptime()
    });
});

app.get('/api/crypto/prices', (req, res) => {
    res.json({
        success: true,
        count: cryptoPrices.length,
        lastUpdated: cryptoPrices[0]?.last_updated || new Date().toISOString(),
        data: cryptoPrices
    });
});

app.get('/api/crypto/prices/:symbol', (req, res) => {
    const symbol = req.params.symbol.toUpperCase();
    const coin = cryptoPrices.find(c => c.symbol === symbol);
    if (!coin) {
        return res.status(404).json({ success: false, error: 'Coin not found' });
    }
    res.json({ success: true, data: coin });
});

app.get('/api/crypto/stats', async (req, res) => {
    try {
        const response = await axios.get(`${COINGECKO_API}/global`, { timeout: 5000 });
        const data = response.data.data;
        res.json({
            success: true,
            data: {
                total_market_cap: data.total_market_cap.usd,
                total_volume: data.total_volume.usd,
                btc_dominance: data.market_cap_percentage.btc,
                eth_dominance: data.market_cap_percentage.eth,
                active_cryptocurrencies: data.active_cryptocurrencies,
                markets: data.markets,
                fear_greed: 74,
                defi_tvl: 95200000000
            }
        });
    } catch (error) {
        res.json({
            success: true,
            data: {
                total_market_cap: 2840000000000,
                total_volume: 128000000000,
                btc_dominance: 52.4,
                eth_dominance: 16.2,
                active_cryptocurrencies: 12045,
                markets: 850,
                fear_greed: 74,
                defi_tvl: 95200000000
            }
        });
    }
});

app.get('/api/crypto/trending', async (req, res) => {
    try {
        const response = await axios.get(`${COINGECKO_API}/search/trending`, { timeout: 5000 });
        res.json({ success: true, data: response.data.coins });
    } catch (error) {
        res.json({ success: true, data: [] });
    }
});

app.get('/api/tv/guide', (req, res) => {
    const day = req.query.day || 'weekday';
    const weekday = [
        { time: '6:00 AM - 9:00 AM', show: 'Morning Pages', channel: 'The Writing Room', status: 'live' },
        { time: '9:00 AM - 12:00 PM', show: 'Crypto Morning Brief', channel: 'Fantazma Finance', status: 'upcoming' },
        { time: '12:00 PM - 2:00 PM', show: 'Portland Stories', channel: 'Maine Chronicles', status: 'upcoming' },
        { time: '2:00 PM - 4:00 PM', show: 'Script Breakdown', channel: 'The Writing Room', status: 'upcoming' },
        { time: '4:00 PM - 6:00 PM', show: 'NFT Showcase Hour', channel: 'Fantazma After Dark', status: 'upcoming' },
        { time: '6:00 PM - 9:00 PM', show: 'The Final Draft', channel: 'The Writing Room', status: 'upcoming' },
        { time: '9:00 PM - 12:00 AM', show: 'Crypto Talk After Dark', channel: 'Fantazma After Dark', status: 'upcoming' }
    ];
    const weekend = [
        { time: '9:00 AM - 12:00 PM', show: 'Weekend Writing Workshop', channel: 'The Writing Room', status: 'upcoming' },
        { time: '10:00 AM - 12:00 PM', show: 'Sunday Documentary Special', channel: 'Maine Chronicles', status: 'upcoming' },
        { time: '12:00 PM - 2:00 PM', show: 'Crypto Deep Dive', channel: 'Fantazma Finance', status: 'upcoming' },
        { time: '2:00 PM - 4:00 PM', show: 'Best of Maine Chronicles', channel: 'Maine Chronicles', status: 'rerun' },
        { time: '3:00 PM - 6:00 PM', show: 'Rewind: The Final Draft', channel: 'The Writing Room', status: 'rerun' },
        { time: '6:00 PM - 8:00 PM', show: 'NFT Creator Spotlight', channel: 'Fantazma After Dark', status: 'upcoming' },
        { time: '9:00 PM - 12:00 AM', show: 'After Dark Weekend', channel: 'Fantazma After Dark', status: 'upcoming' }
    ];
    res.json({ success: true, day, data: day === 'weekend' ? weekend : weekday });
});

app.get('/api/content/library', (req, res) => {
    const library = [
        { id: 1, title: 'The Final Draft S1E1', channel: 'The Writing Room', duration: '45 min', category: 'scriptwriting', thumbnail: 'pen-fancy' },
        { id: 2, title: 'Maine: The Documentary', channel: 'Maine Chronicles', duration: '90 min', category: 'documentary', thumbnail: 'mountain' },
        { id: 3, title: 'Crypto Basics 101', channel: 'Fantazma Finance', duration: '30 min', category: 'education', thumbnail: 'graduation-cap' },
        { id: 4, title: 'After Dark: Pilot', channel: 'Fantazma After Dark', duration: '60 min', category: 'commentary', thumbnail: 'moon' },
        { id: 5, title: 'Portland Harbor Stories', channel: 'Maine Chronicles', duration: '35 min', category: 'documentary', thumbnail: 'ship' },
        { id: 6, title: 'NFT Creation Masterclass', channel: 'Fantazma After Dark', duration: '50 min', category: 'education', thumbnail: 'palette' },
        { id: 7, title: 'Script to Screen', channel: 'The Writing Room', duration: '40 min', category: 'scriptwriting', thumbnail: 'film' },
        { id: 8, title: 'DeFi Explained', channel: 'Fantazma Finance', duration: '25 min', category: 'education', thumbnail: 'chart-pie' }
    ];
    const category = req.query.category;
    if (category) {
        res.json({ success: true, data: library.filter(item => item.category === category) });
    } else {
        res.json({ success: true, count: library.length, data: library });
    }
});

app.get('/api/news', (req, res) => {
    const news = [
        { id: 1, tag: 'crypto', tagName: 'CRYPTO', title: 'Bitcoin ETF Inflows Hit Record $2.4B as Institutional Adoption Accelerates', source: 'CoinDesk', time: '2 hours ago' },
        { id: 2, tag: 'banking', tagName: 'BANKING', title: 'JPMorgan Chase Announces Native Crypto Custody Service for Institutional Clients', source: 'Bloomberg', time: '4 hours ago' },
        { id: 3, tag: 'nft', tagName: 'NFT', title: 'NFT Market Rebounds: Q2 Trading Volume Surges 45% Driven by Gaming Assets', source: 'NFT Now', time: '6 hours ago' },
        { id: 4, tag: 'defi', tagName: 'DEFI', title: 'DeFi Total Value Locked Crosses $100B Milestone for First Time Since 2022', source: 'DeFi Pulse', time: '8 hours ago' },
        { id: 5, tag: 'crypto', tagName: 'REGULATION', title: 'SEC Approves First Spot Ethereum ETFs, Trading to Begin Next Week', source: 'Reuters', time: '12 hours ago' },
        { id: 6, tag: 'banking', tagName: 'CBDC', title: 'Federal Reserve Pilots Digital Dollar Program with 12 Major Banks', source: 'Financial Times', time: '1 day ago' }
    ];
    res.json({ success: true, count: news.length, data: news });
});

app.get('/api/upcoming', (req, res) => {
    const events = [
        { id: 1, title: 'AOC Token Exchange Listing', date: '2026-05-15', desc: 'Alpha Coin Omega listed on Gate.io and MEXC Global. Trading pairs: AOC/USDT and AOC/ETH.', type: 'crypto' },
        { id: 2, title: 'Fantazma NFT Membership Launch', date: '2026-06-01', desc: 'Limited edition 1,000 NFT membership cards. Mint price: 0.05 ETH.', type: 'nft' },
        { id: 3, title: 'Digital Banking Integration', date: '2026-06-15', desc: 'Partnership with crypto-friendly neobank. Debit card with 2% BTC cashback.', type: 'banking' },
        { id: 4, title: 'DeFi Yield Farming Pool', date: '2026-07-01', desc: 'AOC/ETH liquidity pool on Uniswap V4 with 85% APY rewards.', type: 'crypto' }
    ];
    res.json({ success: true, data: events });
});

// Admin routes (protected)
app.get('/api/admin/users', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ success: false, error: 'Admin access required' });
    }

    try {
        let users;
        if (isConnected) {
            users = await User.find().select('-password').sort({ createdAt: -1 });
        } else {
            users = memoryUsers;
        }
        res.json({ success: true, count: users.length, data: users });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Failed to get users' });
    }
});

app.get('/api/admin/payments', authenticateToken, async (req, res) => {
    if (req.user.role !== 'admin') {
        return res.status(403).json({ success: false, error: 'Admin access required' });
    }

    try {
        let payments;
        if (isConnected) {
            payments = await Payment.find().sort({ createdAt: -1 }).limit(100);
        } else {
            payments = memoryPayments;
        }
        res.json({ success: true, count: payments.length, data: payments });
    } catch (error) {
        res.status(500).json({ success: false, error: 'Failed to get payments' });
    }
});

// Error handlers
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ success: false, error: 'Something went wrong!' });
});

app.use((req, res) => {
    res.status(404).json({ success: false, error: 'Endpoint not found' });
});

// Start server
server.listen(PORT, () => {
    console.log('='.repeat(60));
    console.log('  FANTAZMA NETWORK BACKEND API v2.0');
    console.log('  Crypto-Powered Streaming Platform');
    console.log('='.repeat(60));
    console.log(`  Server running on port ${PORT}`);
    console.log(`  WebSocket: ws://localhost:${PORT}`);
    console.log(`  Health: http://localhost:${PORT}/api/health`);
    console.log(`  MongoDB: ${isConnected ? 'Connected' : 'In-memory mode'}`);
    console.log(`  Stripe: ${stripe ? 'Enabled' : 'Disabled'}`);
    console.log('='.repeat(60));
    console.log('  God Bless Your Build');
    console.log('='.repeat(60));
});

module.exports = { app, server, wss };