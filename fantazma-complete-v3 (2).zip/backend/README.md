# Fantazma Network Backend API v2.0

Crypto-powered streaming platform backend with MongoDB, Stripe payments, WebSocket live chat, and real-time crypto prices.

## Features

- **MongoDB Database** - Persistent user accounts, payments, chat history
- **Stripe Integration** - Card payments with $1.89 processing fee
- **JWT Authentication** - Secure token-based auth for email and wallet
- **WebSocket Live Chat** - Real-time messaging with DB persistence
- **Real Crypto Prices** - Live CoinGecko API data (updates every 2 min)
- **Rate Limiting** - Protection against brute force attacks
- **Admin Dashboard** - Protected routes for user/payment management

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Configure environment
cp .env.example .env
# Edit .env with your MongoDB URI, Stripe keys, and JWT secret

# 3. Run locally
npm run dev
```

Server starts on `http://localhost:10000`

## API Documentation

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Create new account |
| POST | `/api/auth/login` | Login with email or wallet |
| GET | `/api/auth/me` | Get current user (requires token) |

### Payments (Stripe)
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/payment/create-session` | Create Stripe checkout |
| POST | `/api/payment/crypto` | Submit crypto payment |
| POST | `/api/payment/webhook` | Stripe webhook handler |

### Crypto
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/crypto/prices` | All tracked coins |
| GET | `/api/crypto/stats` | Market stats |
| GET | `/api/crypto/trending` | Trending coins |

### Content
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/news` | Financial news |
| GET | `/api/upcoming` | Upcoming events |
| GET | `/api/tv/guide` | TV schedule |
| GET | `/api/content/library` | Content library |

### Admin (Requires admin role)
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/users` | List all users |
| GET | `/api/admin/payments` | List all payments |

## WebSocket

Connect to `wss://your-backend.onrender.com`

### Client Messages
```json
{ "type": "chat", "text": "Hello!", "color": "#00d4ff" }
{ "type": "auth", "username": "CryptoKing", "wallet": "metamask", "address": "0x..." }
{ "type": "ping" }
```

### Server Messages
```json
{ "type": "chat", "username": "CryptoKing", "text": "Hello!", "timestamp": "..." }
{ "type": "system", "message": "Welcome!", "onlineCount": 42 }
{ "type": "crypto_update", "data": [...] }
{ "type": "history", "messages": [...] }
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `MONGODB_URI` | Yes | MongoDB connection string |
| `JWT_SECRET` | Yes | Secret for JWT tokens |
| `STRIPE_SECRET_KEY` | No | For card payments |
| `STRIPE_WEBHOOK_SECRET` | No | Stripe webhook verification |
| `FRONTEND_URL` | No | Your frontend domain |
| `COINGECKO_API_KEY` | No | Higher rate limits |

## Deployment

See `DEPLOYMENT_GUIDE.md` for step-by-step Render.com deployment.

## God Bless Your Build