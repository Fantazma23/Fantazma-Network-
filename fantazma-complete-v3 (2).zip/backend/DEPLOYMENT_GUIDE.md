# FANTAZMA NETWORK - DEPLOYMENT GUIDE
# God Bless Your Build

## STEP 1: MongoDB Atlas Setup (5 minutes)

1. Go to https://www.mongodb.com/cloud/atlas
2. Sign up / Log in
3. Click "Build a Database"
4. Choose "FREE SHARED CLUSTER"
5. Select region closest to your users (e.g., AWS / us-east-1)
6. Click "Create Cluster"
7. Create a database user:
   - Username: fantazma_admin
   - Password: [generate strong password]
   - Click "Create User"
8. Add IP Access:
   - Click "Add IP Address"
   - Choose "Allow Access from Anywhere" (0.0.0.0/0)
   - Click "Confirm"
9. Get connection string:
   - Click "Connect" → "Drivers" → "Node.js"
   - Copy the connection string
   - Replace `<password>` with your actual password
   - Replace `myFirstDatabase` with `fantazma`

Example:
```
mongodb+srv://fantazma_admin:YourPassword123@cluster0.xxxxx.mongodb.net/fantazma?retryWrites=true&w=majority
```

## STEP 2: Stripe Setup (10 minutes)

1. Go to https://dashboard.stripe.com/register
2. Create a free account
3. Get your API keys:
   - Test mode: https://dashboard.stripe.com/test/apikeys
   - Publishable key: pk_test_...
   - Secret key: sk_test_...
4. Set up webhook:
   - Go to https://dashboard.stripe.com/test/webhooks
   - Click "Add endpoint"
   - Endpoint URL: `https://your-backend.onrender.com/api/payment/webhook`
   - Select events: `checkout.session.completed`
   - Copy the webhook signing secret: `whsec_...`

## STEP 3: Render.com Backend Deployment (5 minutes)

### Option A: Using Render Dashboard

1. Go to https://dashboard.render.com
2. Click "New +" → "Web Service"
3. Connect your GitHub repo or upload files
4. Configure:
   - **Name**: fantazma-api
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `npm start`
   - **Plan**: Free
5. Add Environment Variables:
   ```
   NODE_ENV=production
   PORT=10000
   FRONTEND_URL=https://fantazma-network.onrender.com
   JWT_SECRET=[generate with: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"]
   MONGODB_URI=[your MongoDB connection string]
   STRIPE_SECRET_KEY=sk_test_...
   STRIPE_WEBHOOK_SECRET=whsec_...
   ```
6. Click "Create Web Service"
7. Wait for deployment (2-3 minutes)

### Option B: Using render.yaml (Blueprints)

1. Push `render.yaml` to your repo root
2. Go to https://dashboard.render.com/blueprints
3. Click "New Blueprint Instance"
4. Connect your repo
5. Render will auto-detect the configuration
6. Fill in the secret environment variables
7. Deploy

## STEP 4: Update Frontend API URLs

In `dashboard.html`, change:
```javascript
const API_BASE = 'https://fantazma-api.onrender.com/api';  // Your backend URL
const WS_URL = 'wss://fantazma-api.onrender.com';          // Your backend URL
```

Also update in `login.html` if you add API calls there.

## STEP 5: Test Everything

1. **Health Check**: Visit `https://your-backend.onrender.com/api/health`
   Should return: `{ "status": "ok", "dbConnected": true, "stripeEnabled": true }`

2. **Crypto Prices**: `https://your-backend.onrender.com/api/crypto/prices`
   Should return live CoinGecko data

3. **WebSocket**: Open dashboard, chat should connect

4. **Stripe Payment**: Click subscribe, should redirect to Stripe checkout

5. **Registration**: Test email signup at `/api/auth/register`

## TROUBLESHOOTING

### MongoDB not connecting?
- Check IP whitelist (must include 0.0.0.0/0)
- Verify password in connection string
- Check network access in Atlas

### Stripe webhook failing?
- Verify webhook URL is correct
- Check STRIPE_WEBHOOK_SECRET matches
- Ensure endpoint is listening to `checkout.session.completed`

### CORS errors?
- Update FRONTEND_URL to match your actual frontend domain
- Add any additional domains to the CORS origin array

### WebSocket not connecting?
- Use `wss://` (secure) not `ws://`
- Check firewall/port settings
- Verify WebSocket server is running

## PRODUCTION CHECKLIST

- [ ] MongoDB Atlas cluster created
- [ ] Database user created with password
- [ ] IP whitelist set to 0.0.0.0/0
- [ ] Stripe account created
- [ ] Stripe API keys obtained
- [ ] Stripe webhook configured
- [ ] Backend deployed to Render
- [ ] Environment variables set
- [ ] Frontend API URLs updated
- [ ] Health check passing
- [ ] Crypto prices loading
- [ ] WebSocket chat working
- [ ] Stripe payment test completed
- [ ] SSL/HTTPS enabled

## God Bless Your Build

For help, email: support@fantazma.network