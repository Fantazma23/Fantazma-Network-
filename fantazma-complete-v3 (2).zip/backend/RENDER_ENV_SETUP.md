# RENDER.COM ENVIRONMENT VARIABLES SETUP
# ==========================================

## Where to add these:
## Render Dashboard → Your Service → Environment → Add Environment Variable

## REQUIRED VARIABLES (Add these first):

NODE_ENV=production
PORT=10000
FRONTEND_URL=https://fantazma-network.onrender.com

## MONGODB (Replace <YOUR_PASSWORD> with actual password):
## Format: mongodb+srv://username:password@cluster/database
MONGODB_URI=mongodb+srv://davidjfantazma_db_user:YOUR_PASSWORD_HERE@cluster0.fsfwxkc.mongodb.net/fantazma?retryWrites=true&w=majority

## JWT SECRET (Generate with: node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"):
JWT_SECRET=YOUR_64_CHAR_RANDOM_STRING_HERE

## STRIPE (Get from https://dashboard.stripe.com/apikeys):
STRIPE_SECRET_KEY=sk_test_YOUR_STRIPE_SECRET_KEY
STRIPE_WEBHOOK_SECRET=whsec_YOUR_STRIPE_WEBHOOK_SECRET
STRIPE_PUBLISHABLE_KEY=pk_test_YOUR_STRIPE_PUBLISHABLE_KEY

## ADMIN (Optional):
ADMIN_EMAIL=admin@fantazma.network
ADMIN_PASSWORD=YOUR_ADMIN_PASSWORD